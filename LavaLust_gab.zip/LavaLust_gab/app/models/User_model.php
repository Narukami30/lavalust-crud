<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class User_model extends Model {

    public function read() {
        return $this->db->table('mbgb_users')->get_all();
    }

    public function create($mbgb_last_name, $mbgb_first_name, $mbgb_email, $mbgb_gender, $mbgb_address) {
        $data = array(
            'mbgb_last_name' => $mbgb_last_name,
            'mbgb_first_name' => $mbgb_first_name,
            'mbgb_email' => $mbgb_email,
            'mbgb_gender' => $mbgb_gender,
            'mbgb_address' => $mbgb_address
        );

        return $this->db->table('mbgb_users')->insert($data);
    }

    public function get_one($id) {
        return $this->db->table('mbgb_users')
                        ->where('id', $id)
                        ->get();  
    }

    public function update($id, $mbgb_last_name, $mbgb_first_name, $mbgb_email, $mbgb_gender, $mbgb_address) {
        $data = array(
            'mbgb_last_name' => $mbgb_last_name,
            'mbgb_first_name' => $mbgb_first_name,
            'mbgb_email' => $mbgb_email,
            'mbgb_gender' => $mbgb_gender,
            'mbgb_address' => $mbgb_address
        );

        return $this->db->table('mbgb_users')
                        ->where('id', $id)
                        ->update($data);
    }

    public function delete($id) {
        return $this->db->table('mbgb_users')->where('id', $id)->delete();
    }
}
