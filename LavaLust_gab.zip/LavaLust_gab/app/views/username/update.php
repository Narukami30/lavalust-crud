<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-3">
        <h2>Update User</h2>

        <?php if (isset($_SESSION['flash_alert'])): ?>
    <div class="alert alert-<?= $_SESSION['flash_alert']['type']; ?>">
        <?= $_SESSION['flash_alert']['message']; ?>
        <?php unset($_SESSION['flash_alert']); ?>
    </div>
<?php endif; ?>

        <form action="<?= site_url('user/update/' . $user['id']); ?>" method="POST">
            <div class="mb-3">
                <label for="mbgb_last_name">Last Name:</label>
                <input type="text" class="form-control" id="mbgb_last_name" name="mbgb_last_name" value="<?= $user['mbgb_last_name']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="mbgb_first_name">First Name:</label>
                <input type="text" class="form-control" id="mbgb_first_name" name="mbgb_first_name" value="<?= $user['mbgb_first_name']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="mbgb_email">Email:</label>
                <input type="email" class="form-control" id="mbgb_email" name="mbgb_email" value="<?= $user['mbgb_email']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="mbgb_gender">Gender:</label>
                <select class="form-control" id="mbgb_gender" name="mbgb_gender" required>
                    <option value="">Select</option>
                    <option value="Male" <?= $user['mbgb_gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?= $user['mbgb_gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                    <option value="Other" <?= $user['mbgb_gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="mbgb_address">Address:</label>
                <input type="text" class="form-control" id="mbgb_address" name="mbgb_address" value="<?= $user['mbgb_address']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
